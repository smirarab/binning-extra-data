This archive was made by Theo Zimmermann for use by anybody.

It contains XML *BEAST input files that were used in the analyses of
the 11-taxon simulated datasets presented in the paper ``BBCA:
Improving the scalability of *BEAST using random binning''.  This
paper will appear at RECOMB-CG 2014. Its authors are Theo Zimmermann,
Siavash Mirarab and Tandy Warnow.

All these input files were generated using a script called
``create_beast_input.pl'' by Jimmy Yang which was also made publicly
available.

Inside this archive, you will find 10 folders corresponding to 10
replicates. We have divided each of these in 4 bins of 25 genes (named
bins.25.bin.[1-4]) and 2 bins of 50 genes (named bins.50.bin.[1-2]).
We have also a *BEAST input file corresponding to the full set of 100
genes (named bins.100.bin.1).
